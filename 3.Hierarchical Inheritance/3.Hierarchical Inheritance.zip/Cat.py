from animal import Animal
class cat(Animal):
    def meow(self):
        return f"meowing..."