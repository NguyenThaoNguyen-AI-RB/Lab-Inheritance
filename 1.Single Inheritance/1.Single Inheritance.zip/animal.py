class Animal:
    def eat(self):
        return f"eat ..."